document.location = 'https://jok.ge';
